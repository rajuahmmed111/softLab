import { Component } from '@angular/core';

@Component({
  selector: 'app-video-play-section',
  templateUrl: './video-play-section.component.html',
  styleUrls: ['./video-play-section.component.scss']
})
export class VideoPlaySectionComponent {

}
